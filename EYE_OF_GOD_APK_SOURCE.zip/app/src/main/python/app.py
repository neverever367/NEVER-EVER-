"""EYE OF GOD v0.2.0 — serveur Flask embarqué dans l'APK (ou lancé seul pour test).
Chemins fournis par launcher.py via EOG_WEB (modèles/statique) et EOG_DATA (base, clé)."""
import os, sys, socket, sqlite3, ipaddress, secrets, shutil
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone, timedelta
from functools import wraps
from flask import (Flask, g, render_template, request, redirect,
                   url_for, session, flash, abort)
from werkzeug.security import generate_password_hash, check_password_hash

VERSION = "0.2.0"
WEB = os.environ.get("EOG_WEB", os.path.dirname(os.path.abspath(__file__)))
DATA = os.environ.get("EOG_DATA", os.path.join(WEB, "data"))
DB = os.path.join(DATA, "eyeofgod.db")
KEYFILE = os.path.join(DATA, "secret.key")
MAX_FAILS, LOCK_MIN = 5, 15
SCAN_PORTS = (80, 443, 22, 445, 139, 8080, 53, 5555)
SCAN_MAX_HOSTS = 1024

os.makedirs(DATA, exist_ok=True)
if not os.path.exists(KEYFILE):  # clé générée sur l'appareil, jamais dans le code
    with open(KEYFILE, "w") as f:
        f.write(secrets.token_hex(32))

app = Flask(__name__, template_folder=os.path.join(WEB, "templates"),
            static_folder=os.path.join(WEB, "static"))
app.config.update(SECRET_KEY=open(KEYFILE).read().strip(),
                  SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax",
                  PERMANENT_SESSION_LIFETIME=timedelta(hours=8))

# ───────────── Base de données et migrations (jamais de DROP) ─────────────
def mig1(con):  # schéma v0.1.0 (idempotent : sans danger sur une base existante)
    con.executescript("""
    CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'admin', created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS networks (id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL, description TEXT DEFAULT '', cidr TEXT NOT NULL UNIQUE,
      status TEXT NOT NULL DEFAULT 'actif', created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS agents (id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL, os TEXT DEFAULT '', version TEXT DEFAULT '',
      status TEXT NOT NULL DEFAULT 'en attente', last_seen TEXT, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS devices (id INTEGER PRIMARY KEY AUTOINCREMENT,
      network_id INTEGER NOT NULL REFERENCES networks(id), ip TEXT NOT NULL,
      mac TEXT, hostname TEXT, verified INTEGER NOT NULL DEFAULT 0,
      first_seen TEXT NOT NULL, last_seen TEXT NOT NULL, UNIQUE(network_id, ip));
    CREATE TABLE IF NOT EXISTS security_logs (id INTEGER PRIMARY KEY AUTOINCREMENT,
      ts TEXT NOT NULL, event TEXT NOT NULL, username TEXT, ip TEXT, detail TEXT DEFAULT '');
    CREATE INDEX IF NOT EXISTS idx_devices_net ON devices(network_id);
    CREATE INDEX IF NOT EXISTS idx_seclog_event ON security_logs(event, ts);""")

def mig2(con):  # v0.2.0 : réglages + état en ligne + type d'appareil
    con.execute("CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT)")
    cols = [r[1] for r in con.execute("PRAGMA table_info(devices)")]
    if "online" not in cols:
        con.execute("ALTER TABLE devices ADD COLUMN online INTEGER NOT NULL DEFAULT 0")
    if "device_type" not in cols:
        con.execute("ALTER TABLE devices ADD COLUMN device_type TEXT")

MIGRATIONS = [mig1, mig2]

def migrate():
    """Sauvegarde puis applique les migrations manquantes (PRAGMA user_version)."""
    existed = os.path.exists(DB) and os.path.getsize(DB) > 0
    con = sqlite3.connect(DB)
    v = con.execute("PRAGMA user_version").fetchone()[0]
    if v < len(MIGRATIONS):
        if existed:
            bk = os.path.join(DATA, "backups")
            os.makedirs(bk, exist_ok=True)
            shutil.copy2(DB, os.path.join(bk, "eyeofgod_avant_v%d_%s.db" % (
                v, datetime.now().strftime("%Y%m%d_%H%M%S"))))
        for i in range(v, len(MIGRATIONS)):
            MIGRATIONS[i](con)
            con.execute("PRAGMA user_version=%d" % (i + 1))
            con.commit()
    con.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('app_version',?)", (VERSION,))
    con.commit(); con.close()

def now():
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")

def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db

@app.teardown_appcontext
def close_db(_):
    d = g.pop("db", None)
    if d:
        d.close()

def log(event, username=None, detail=""):
    db().execute("INSERT INTO security_logs(ts,event,username,ip,detail) VALUES(?,?,?,?,?)",
                 (now(), event, username, request.remote_addr, detail))
    db().commit()

# ───────────── Sécurité : CSRF, session, verrouillage ─────────────
def csrf_token():
    if "csrf" not in session:
        session["csrf"] = secrets.token_hex(16)
    return session["csrf"]
app.jinja_env.globals.update(csrf_token=csrf_token, version=VERSION)

@app.before_request
def check_csrf():
    if request.method == "POST" and request.form.get("csrf") != session.get("csrf"):
        abort(400, "Jeton CSRF invalide")

def login_required(f):
    @wraps(f)
    def w(*a, **k):
        if "user" not in session:
            return redirect(url_for("login"))
        return f(*a, **k)
    return w

def has_users():
    return db().execute("SELECT COUNT(*) FROM users").fetchone()[0] > 0

def is_locked(username):
    since = (datetime.now(timezone.utc) - timedelta(minutes=LOCK_MIN)).strftime("%Y-%m-%d %H:%M:%S")
    n = db().execute("SELECT COUNT(*) FROM security_logs WHERE event='login_failed' "
                     "AND username=? AND ts>?", (username, since)).fetchone()[0]
    return n >= MAX_FAILS

@app.route("/setup", methods=["GET", "POST"])
def setup():
    if has_users():
        return redirect(url_for("login"))
    if request.method == "POST":
        u = request.form.get("username", "").strip()
        p, p2 = request.form.get("password", ""), request.form.get("password2", "")
        if not u:
            flash("Le nom d'administrateur est obligatoire.")
        elif len(p) < 10:
            flash("Mot de passe trop court (10 caractères minimum).")
        elif p != p2:
            flash("Les deux mots de passe ne correspondent pas.")
        else:
            db().execute("INSERT INTO users(username,password_hash,role,created_at) VALUES(?,?,'admin',?)",
                         (u, generate_password_hash(p), now()))
            db().commit()
            log("admin_created", u)
            flash("Administrateur créé. Connectez-vous.")
            return redirect(url_for("login"))
    return render_template("setup.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if not has_users():
        return redirect(url_for("setup"))
    if request.method == "POST":
        u = request.form.get("username", "").strip()
        p = request.form.get("password", "")
        if is_locked(u):
            flash("Trop de tentatives. Réessayez dans %d minutes." % LOCK_MIN)
            return render_template("login.html")
        row = db().execute("SELECT * FROM users WHERE username=?", (u,)).fetchone()
        if row and check_password_hash(row["password_hash"], p):
            session.clear()
            session.permanent = True
            session["user"], session["role"] = u, row["role"]
            log("login_ok", u)
            return redirect(url_for("dashboard"))
        log("login_failed", u)
        flash("Identifiants incorrects.")
    return render_template("login.html")

@app.route("/logout", methods=["POST"])
def logout():
    log("logout", session.get("user"))
    session.clear()
    return redirect(url_for("login"))

# ───────────── Pages ─────────────
@app.route("/")
@login_required
def dashboard():
    c = lambda q: db().execute(q).fetchone()[0]
    stats = {"reseaux": c("SELECT COUNT(*) FROM networks"),
             "agents": c("SELECT COUNT(*) FROM agents WHERE status='actif'"),
             "agents_off": c("SELECT COUNT(*) FROM agents WHERE status!='actif'"),
             "appareils": c("SELECT COUNT(*) FROM devices"),
             "en_ligne": c("SELECT COUNT(*) FROM devices WHERE online=1"),
             "echecs": c("SELECT COUNT(*) FROM security_logs WHERE event='login_failed' "
                         "AND ts > datetime('now','-1 day')")}
    logs = db().execute("SELECT * FROM security_logs ORDER BY id DESC LIMIT 8").fetchall()
    return render_template("dashboard.html", s=stats, logs=logs)

@app.route("/journal")
@login_required
def journal():
    logs = db().execute("SELECT * FROM security_logs ORDER BY id DESC LIMIT 200").fetchall()
    return render_template("journal.html", logs=logs)

@app.route("/devices")
@login_required
def devices():
    rows = db().execute("SELECT d.*, n.name AS net FROM devices d JOIN networks n "
                        "ON n.id=d.network_id ORDER BY d.online DESC, d.ip").fetchall()
    return render_template("devices.html", rows=rows)

# ───────────── Réseaux ─────────────
def valid_cidr(txt):
    """IPv4 privée uniquement ; accepte une IP seule (/32) ou une plage jusqu'à /16."""
    try:
        net = ipaddress.ip_network(txt.strip(), strict=False)
    except ValueError:
        return None, "Plage invalide (ex. 192.168.1.0/24 ou 192.168.1.20)."
    if net.version != 4 or not net.is_private:
        return None, "Seules les adresses IPv4 privées sont autorisées."
    if net.prefixlen < 16:
        return None, "Plage trop large (minimum /16)."
    return str(net), None

@app.route("/networks", methods=["GET", "POST"])
@login_required
def networks():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        cidr, err = valid_cidr(request.form.get("cidr", ""))
        if not name:
            err = "Le nom est obligatoire."
        if err:
            flash(err)
        else:
            try:
                db().execute("INSERT INTO networks(name,description,cidr,created_at) VALUES(?,?,?,?)",
                             (name, request.form.get("description", "").strip(), cidr, now()))
                db().commit()
                log("network_added", session["user"], "%s %s" % (name, cidr))
                flash("Réseau enregistré.")
            except sqlite3.IntegrityError:
                flash("Cette plage existe déjà.")
        return redirect(url_for("networks"))
    rows = db().execute("SELECT n.*, (SELECT COUNT(*) FROM devices d WHERE d.network_id=n.id) AS nb "
                        "FROM networks n ORDER BY n.id DESC").fetchall()
    return render_template("networks.html", rows=rows)

@app.route("/networks/<int:nid>/edit", methods=["POST"])
@login_required
def network_edit(nid):
    name = request.form.get("name", "").strip()
    if not name:
        flash("Le nom est obligatoire.")
    else:
        db().execute("UPDATE networks SET name=?, description=? WHERE id=?",
                     (name, request.form.get("description", "").strip(), nid))
        db().commit()
        log("network_edited", session["user"], "id=%d %s" % (nid, name))
        flash("Réseau modifié.")
    return redirect(url_for("networks"))

@app.route("/networks/<int:nid>/delete", methods=["POST"])
@login_required
def network_delete(nid):
    n = db().execute("SELECT * FROM networks WHERE id=?", (nid,)).fetchone()
    if n:
        db().execute("DELETE FROM devices WHERE network_id=?", (nid,))
        db().execute("DELETE FROM networks WHERE id=?", (nid,))
        db().commit()
        log("network_deleted", session["user"], "%s %s" % (n["name"], n["cidr"]))
        flash("Réseau supprimé.")
    return redirect(url_for("networks"))

# ───────────── Détection (limites réelles d'Android) ─────────────
def probe(ip):
    """Hôte considéré actif s'il accepte (0) ou refuse (ECONNREFUSED) une connexion TCP.
    Un hôte qui ne répond à aucun de ces ports (pare-feu) ne sera PAS détecté."""
    for p in SCAN_PORTS:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(0.35)
        try:
            r = s.connect_ex((ip, p))
            if r in (0, 111):
                return ip
        except OSError:
            pass
        finally:
            s.close()
    return None

def read_arp():
    """Lit /proc/net/arp. Souvent inaccessible/vide sur Android 10+ ; vérifié seulement si présent."""
    table = {}
    try:
        with open("/proc/net/arp") as f:
            next(f, None)
            for line in f:
                c = line.split()
                if len(c) >= 4 and c[3] != "00:00:00:00:00:00" and c[2] != "0x0":
                    table[c[0]] = c[3].lower()
    except OSError:
        pass
    return table

@app.route("/networks/<int:nid>/scan", methods=["POST"])
@login_required
def network_scan(nid):
    n = db().execute("SELECT * FROM networks WHERE id=?", (nid,)).fetchone()
    if not n:
        abort(404)
    net = ipaddress.ip_network(n["cidr"])           # plage ENREGISTRÉE uniquement
    hosts = [str(h) for h in (net.hosts() if net.num_addresses > 1 else [net.network_address])]
    if len(hosts) > SCAN_MAX_HOSTS:
        flash("Plage trop grande pour un scan (maximum %d adresses, soit /22)." % SCAN_MAX_HOSTS)
        return redirect(url_for("networks"))
    with ThreadPoolExecutor(max_workers=64) as ex:
        found = [ip for ip in ex.map(probe, hosts) if ip]
    arp, t = read_arp(), now()
    db().execute("UPDATE devices SET online=0 WHERE network_id=?", (nid,))
    for ip in found:
        mac = arp.get(ip)
        db().execute(
            "INSERT INTO devices(network_id,ip,mac,verified,online,first_seen,last_seen) "
            "VALUES(?,?,?,?,1,?,?) ON CONFLICT(network_id,ip) DO UPDATE SET "
            "online=1, last_seen=excluded.last_seen, "
            "mac=COALESCE(excluded.mac, mac), verified=MAX(verified, excluded.verified)",
            (nid, ip, mac, 1 if mac else 0, t, t))
    db().commit()
    log("scan", session["user"], "%s : %d appareil(s) détecté(s) sur %d adresses" % (n["cidr"], len(found), len(hosts)))
    flash("Scan terminé : %d appareil(s) détecté(s)." % len(found))
    return redirect(url_for("devices"))

if __name__ == "__main__":  # test hors Android
    migrate()
    app.run(host="127.0.0.1", port=5000)
