"""Point d'entrée appelé par MainActivity.kt : prépare la base puis lance le serveur local."""
import os, threading

_server = None

def start(web_dir, data_dir, port):
    global _server
    if _server is not None:           # déjà démarré (rotation d'écran, etc.)
        return
    os.environ["EOG_WEB"] = web_dir
    os.environ["EOG_DATA"] = data_dir
    import app as eog
    eog.migrate()                      # sauvegarde + migrations, sans jamais supprimer de données
    from werkzeug.serving import make_server
    _server = make_server("127.0.0.1", int(port), eog.app, threaded=True)
    threading.Thread(target=_server.serve_forever, daemon=True).start()

def stop():
    global _server
    if _server is not None:
        _server.shutdown()
        _server = None
