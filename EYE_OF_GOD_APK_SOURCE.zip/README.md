# EYE OF GOD — APK Android autonome (v0.2.0)

Application Android qui embarque son propre serveur (Python/Flask via Chaquopy) et sa base SQLite.
Aucun Termux, Pydroid ou terminal nécessaire. Données dans l'espace privé de l'application.

## Obtenir l'APK depuis le téléphone
1. Sur github.com : **New repository** → nom `eyeofgod` → *Create repository*.
2. **Add file → Upload files** : envoyez le fichier ZIP tel quel (sans le décompresser).
3. **Add file → Create new file** : nom `.github/workflows/build.yml`, collez le workflow fourni dans la conversation, *Commit changes*.
4. Onglet **Actions** → « Compiler EYE OF GOD (APK) » → attendre la coche verte (10 à 15 min la 1ʳᵉ fois).
   Si elle ne démarre pas seule : *Run workflow*.
5. Ouvrir l'exécution → section **Artifacts** → télécharger `EYE-OF-GOD-apk` (ZIP contenant `app-debug.apk`).
6. Décompresser, ouvrir `app-debug.apk`, autoriser « sources inconnues » si demandé, installer.

## Première utilisation
Ouvrir EYE OF GOD → écran « Première configuration » → créer l'administrateur → se connecter.

## Mises à jour sans perte de données
- Remplacez les fichiers modifiés dans GitHub, relancez la compilation, installez le nouvel APK **par-dessus**
  (ne désinstallez jamais l'ancien : cela effacerait les données).
- La clé de signature (`app/debug.keystore`) est fixe : c'est ce qui permet la mise à jour par-dessus.
- Au démarrage, la base est sauvegardée puis migrée (`PRAGMA user_version`), sans DROP.
  Sauvegardes dans l'espace privé de l'appli : `data/backups/`.

## Limites
- Détection par connexions TCP : pas de ping ICMP, pas de Nmap, MAC souvent indisponible sans root.
- APK « debug » : pour usage personnel, pas pour le Play Store.
- Le serveur écoute sur 127.0.0.1 uniquement (non joignable depuis le réseau).
