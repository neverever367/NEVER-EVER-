"""EYE OF GOD v0.2.0 — serveur Flask embarqué dans l'APK (ou lancé seul pour test).
Chemins fournis par launcher.py via EOG_WEB (modèles/statique) et EOG_DATA (base, clé)."""
import os, sys, math, json, socket, urllib.request, sqlite3, ipaddress, secrets, shutil
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone, timedelta
from functools import wraps
from flask import (Flask, g, jsonify, render_template, request, redirect,
                   url_for, session, flash, abort)
from werkzeug.security import generate_password_hash, check_password_hash

VERSION = "0.3.0"
WEB = os.environ.get("EOG_WEB", os.path.dirname(os.path.abspath(__file__)))
DATA = os.environ.get("EOG_DATA", os.path.join(WEB, "data"))
DB = os.path.join(DATA, "eyeofgod.db")
KEYFILE = os.path.join(DATA, "secret.key")
MAX_FAILS, LOCK_MIN = 5, 15
SCAN_PORTS = (80, 443, 22, 445, 139, 8080, 53, 5555)
SCAN_MAX_HOSTS = 1024

os.makedirs(DATA, exist_ok=True)
if not os.path.exists(KEYFILE):  # clé générée sur l'appareil, jamais dans le code
    with open(KEYFILE, "w") as f:
        f.write(secrets.token_hex(32))

app = Flask(__name__, template_folder=os.path.join(WEB, "templates"),
            static_folder=os.path.join(WEB, "static"))
app.config.update(SECRET_KEY=open(KEYFILE).read().strip(),
                  SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax",
                  PERMANENT_SESSION_LIFETIME=timedelta(hours=8),
                  SESSION_COOKIE_SECURE=os.environ.get("EOG_HTTPS") == "1")

# ───────────── Base de données et migrations (jamais de DROP) ─────────────
def mig1(con):  # schéma v0.1.0 (idempotent : sans danger sur une base existante)
    con.executescript("""
    CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'admin', created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS networks (id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL, description TEXT DEFAULT '', cidr TEXT NOT NULL UNIQUE,
      status TEXT NOT NULL DEFAULT 'actif', created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS agents (id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL, os TEXT DEFAULT '', version TEXT DEFAULT '',
      status TEXT NOT NULL DEFAULT 'en attente', last_seen TEXT, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS devices (id INTEGER PRIMARY KEY AUTOINCREMENT,
      network_id INTEGER NOT NULL REFERENCES networks(id), ip TEXT NOT NULL,
      mac TEXT, hostname TEXT, verified INTEGER NOT NULL DEFAULT 0,
      first_seen TEXT NOT NULL, last_seen TEXT NOT NULL, UNIQUE(network_id, ip));
    CREATE TABLE IF NOT EXISTS security_logs (id INTEGER PRIMARY KEY AUTOINCREMENT,
      ts TEXT NOT NULL, event TEXT NOT NULL, username TEXT, ip TEXT, detail TEXT DEFAULT '');
    CREATE INDEX IF NOT EXISTS idx_devices_net ON devices(network_id);
    CREATE INDEX IF NOT EXISTS idx_seclog_event ON security_logs(event, ts);""")

def mig2(con):  # v0.2.0 : réglages + état en ligne + type d'appareil
    con.execute("CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT)")
    cols = [r[1] for r in con.execute("PRAGMA table_info(devices)")]
    if "online" not in cols:
        con.execute("ALTER TABLE devices ADD COLUMN online INTEGER NOT NULL DEFAULT 0")
    if "device_type" not in cols:
        con.execute("ALTER TABLE devices ADD COLUMN device_type TEXT")

def mig3(con):  # v0.3.0 : rôles, appareils clients, consentement, positions, alertes
    cols = [r[1] for r in con.execute("PRAGMA table_info(users)")]
    if "active" not in cols:
        con.execute("ALTER TABLE users ADD COLUMN active INTEGER NOT NULL DEFAULT 1")
    # le premier administrateur existant devient propriétaire (super_admin) ; comptes conservés
    con.execute("UPDATE users SET role='super_admin' WHERE role='admin' AND id=(SELECT MIN(id) FROM users)")
    con.executescript("""
    CREATE TABLE IF NOT EXISTS roles (name TEXT PRIMARY KEY, label TEXT NOT NULL);
    INSERT OR IGNORE INTO roles VALUES ('super_admin','Super administrateur'),('admin','Administrateur'),('client','Client');
    CREATE TABLE IF NOT EXISTS client_devices (id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id), name TEXT NOT NULL,
      device_type TEXT NOT NULL DEFAULT 'telephone', os TEXT DEFAULT '',
      share_gps INTEGER NOT NULL DEFAULT 0, share_ip INTEGER NOT NULL DEFAULT 0,
      last_seen TEXT, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS location_consents (id INTEGER PRIMARY KEY AUTOINCREMENT,
      device_id INTEGER NOT NULL REFERENCES client_devices(id) ON DELETE CASCADE,
      kind TEXT NOT NULL, granted INTEGER NOT NULL, ts TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS device_locations (id INTEGER PRIMARY KEY AUTOINCREMENT,
      device_id INTEGER NOT NULL REFERENCES client_devices(id) ON DELETE CASCADE,
      lat REAL NOT NULL, lon REAL NOT NULL, accuracy REAL, measured_at TEXT NOT NULL, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS ip_estimates (id INTEGER PRIMARY KEY AUTOINCREMENT,
      device_id INTEGER NOT NULL REFERENCES client_devices(id) ON DELETE CASCADE,
      ip TEXT, lat REAL, lon REAL, city TEXT, region TEXT, country TEXT, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS alerts (id INTEGER PRIMARY KEY AUTOINCREMENT,
      ts TEXT NOT NULL, level TEXT NOT NULL DEFAULT 'info', message TEXT NOT NULL);
    CREATE INDEX IF NOT EXISTS idx_cdev_user ON client_devices(user_id);
    CREATE INDEX IF NOT EXISTS idx_loc_dev ON device_locations(device_id, id);
    CREATE INDEX IF NOT EXISTS idx_loc_created ON device_locations(created_at);
    CREATE INDEX IF NOT EXISTS idx_ipe_dev ON ip_estimates(device_id, id);
    INSERT OR IGNORE INTO settings(key,value) VALUES ('allow_signup','0'),('retention_days','30');""")

MIGRATIONS = [mig1, mig2, mig3]

def migrate():
    """Sauvegarde puis applique les migrations manquantes (PRAGMA user_version)."""
    existed = os.path.exists(DB) and os.path.getsize(DB) > 0
    con = sqlite3.connect(DB)
    v = con.execute("PRAGMA user_version").fetchone()[0]
    if v < len(MIGRATIONS):
        if existed:
            bk = os.path.join(DATA, "backups")
            os.makedirs(bk, exist_ok=True)
            shutil.copy2(DB, os.path.join(bk, "eyeofgod_avant_v%d_%s.db" % (
                v, datetime.now().strftime("%Y%m%d_%H%M%S"))))
        for i in range(v, len(MIGRATIONS)):
            MIGRATIONS[i](con)
            con.execute("PRAGMA user_version=%d" % (i + 1))
            con.commit()
    con.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('app_version',?)", (VERSION,))
    con.commit(); con.close()
    purge_old()

def now():
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")

def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db

@app.teardown_appcontext
def close_db(_):
    d = g.pop("db", None)
    if d:
        d.close()

def log(event, username=None, detail=""):
    db().execute("INSERT INTO security_logs(ts,event,username,ip,detail) VALUES(?,?,?,?,?)",
                 (now(), event, username, request.remote_addr, detail))
    db().commit()

# ───────────── Sécurité : CSRF, session, verrouillage ─────────────
def csrf_token():
    if "csrf" not in session:
        session["csrf"] = secrets.token_hex(16)
    return session["csrf"]
app.jinja_env.globals.update(csrf_token=csrf_token, version=VERSION)

@app.before_request
def check_csrf():
    tok = request.form.get("csrf") or request.headers.get("X-CSRF")
    if request.method == "POST" and tok != session.get("csrf"):
        abort(400, "Jeton CSRF invalide")

def login_required(f):
    @wraps(f)
    def w(*a, **k):
        if "user" not in session:
            return redirect(url_for("login"))
        return f(*a, **k)
    return w

ADMINS = ("super_admin", "admin")

def role_required(*roles):
    def deco(f):
        @wraps(f)
        def w(*a, **k):
            if "user" not in session:
                return redirect(url_for("login"))
            if session.get("role") not in roles:
                abort(403)
            return f(*a, **k)
        return w
    return deco

@app.before_request
def check_active():  # un compte désactivé est déconnecté immédiatement
    if "uid" in session:
        r = db().execute("SELECT active, role FROM users WHERE id=?", (session["uid"],)).fetchone()
        if not r or not r["active"]:
            session.clear()
        else:
            session["role"] = r["role"]

def has_users():
    return db().execute("SELECT COUNT(*) FROM users").fetchone()[0] > 0

def is_locked(username):
    since = (datetime.now(timezone.utc) - timedelta(minutes=LOCK_MIN)).strftime("%Y-%m-%d %H:%M:%S")
    n = db().execute("SELECT COUNT(*) FROM security_logs WHERE event='login_failed' "
                     "AND username=? AND ts>?", (username, since)).fetchone()[0]
    return n >= MAX_FAILS

@app.route("/setup", methods=["GET", "POST"])
def setup():
    if has_users():
        return redirect(url_for("login"))
    if request.method == "POST":
        u = request.form.get("username", "").strip()
        p, p2 = request.form.get("password", ""), request.form.get("password2", "")
        if not u:
            flash("Le nom d'administrateur est obligatoire.")
        elif len(p) < 10:
            flash("Mot de passe trop court (10 caractères minimum).")
        elif p != p2:
            flash("Les deux mots de passe ne correspondent pas.")
        else:
            db().execute("INSERT INTO users(username,password_hash,role,created_at) VALUES(?,?,'super_admin',?)",
                         (u, generate_password_hash(p), now()))
            db().commit()
            log("admin_created", u)
            flash("Administrateur créé. Connectez-vous.")
            return redirect(url_for("login"))
    return render_template("setup.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if not has_users():
        return redirect(url_for("setup"))
    if request.method == "POST":
        u = request.form.get("username", "").strip()
        p = request.form.get("password", "")
        if is_locked(u):
            flash("Trop de tentatives. Réessayez dans %d minutes." % LOCK_MIN)
            return render_template("login.html")
        row = db().execute("SELECT * FROM users WHERE username=?", (u,)).fetchone()
        if row and row["active"] and check_password_hash(row["password_hash"], p):
            session.clear()
            session.permanent = True
            session["user"], session["role"], session["uid"] = u, row["role"], row["id"]
            log("login_ok", u)
            return redirect(url_for("dashboard"))
        log("login_failed", u)
        flash("Identifiants incorrects.")
    return render_template("login.html")

@app.route("/logout", methods=["POST"])
def logout():
    log("logout", session.get("user"))
    session.clear()
    return redirect(url_for("login"))

# ───────────── Pages ─────────────
@app.route("/")
@login_required
def dashboard():
    if session.get("role") not in ADMINS:
        return redirect(url_for("me"))
    c = lambda q: db().execute(q).fetchone()[0]
    stats = {"reseaux": c("SELECT COUNT(*) FROM networks"),
             "agents": c("SELECT COUNT(*) FROM agents WHERE status='actif'"),
             "agents_off": c("SELECT COUNT(*) FROM agents WHERE status!='actif'"),
             "appareils": c("SELECT COUNT(*) FROM devices"),
             "en_ligne": c("SELECT COUNT(*) FROM devices WHERE online=1"),
             "clients": c("SELECT COUNT(*) FROM users WHERE role='client'"),
             "appareils_clients": c("SELECT COUNT(*) FROM client_devices"),
             "gps_actifs": c("SELECT COUNT(*) FROM client_devices WHERE share_gps=1"),
             "ip_actifs": c("SELECT COUNT(*) FROM client_devices WHERE share_ip=1"),
             "echecs": c("SELECT COUNT(*) FROM security_logs WHERE event='login_failed' "
                         "AND ts > datetime('now','-1 day')")}
    logs = db().execute("SELECT * FROM security_logs ORDER BY id DESC LIMIT 8").fetchall()
    alerts = db().execute("SELECT * FROM alerts ORDER BY id DESC LIMIT 5").fetchall()
    return render_template("dashboard.html", s=stats, logs=logs, alerts=alerts)

@app.route("/journal")
@role_required(*ADMINS)
def journal():
    logs = db().execute("SELECT * FROM security_logs ORDER BY id DESC LIMIT 200").fetchall()
    return render_template("journal.html", logs=logs)

@app.route("/devices")
@role_required(*ADMINS)
def devices():
    rows = db().execute("SELECT d.*, n.name AS net FROM devices d JOIN networks n "
                        "ON n.id=d.network_id ORDER BY d.online DESC, d.ip").fetchall()
    return render_template("devices.html", rows=rows)

# ───────────── Réseaux ─────────────
def valid_cidr(txt):
    """IPv4 privée uniquement ; accepte une IP seule (/32) ou une plage jusqu'à /16."""
    try:
        net = ipaddress.ip_network(txt.strip(), strict=False)
    except ValueError:
        return None, "Plage invalide (ex. 192.168.1.0/24 ou 192.168.1.20)."
    if net.version != 4 or not net.is_private:
        return None, "Seules les adresses IPv4 privées sont autorisées."
    if net.prefixlen < 16:
        return None, "Plage trop large (minimum /16)."
    return str(net), None

@app.route("/networks", methods=["GET", "POST"])
@role_required(*ADMINS)
def networks():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        cidr, err = valid_cidr(request.form.get("cidr", ""))
        if not name:
            err = "Le nom est obligatoire."
        if err:
            flash(err)
        else:
            try:
                db().execute("INSERT INTO networks(name,description,cidr,created_at) VALUES(?,?,?,?)",
                             (name, request.form.get("description", "").strip(), cidr, now()))
                db().commit()
                log("network_added", session["user"], "%s %s" % (name, cidr))
                flash("Réseau enregistré.")
            except sqlite3.IntegrityError:
                flash("Cette plage existe déjà.")
        return redirect(url_for("networks"))
    rows = db().execute("SELECT n.*, (SELECT COUNT(*) FROM devices d WHERE d.network_id=n.id) AS nb "
                        "FROM networks n ORDER BY n.id DESC").fetchall()
    return render_template("networks.html", rows=rows)

@app.route("/networks/<int:nid>/edit", methods=["POST"])
@role_required(*ADMINS)
def network_edit(nid):
    name = request.form.get("name", "").strip()
    if not name:
        flash("Le nom est obligatoire.")
    else:
        db().execute("UPDATE networks SET name=?, description=? WHERE id=?",
                     (name, request.form.get("description", "").strip(), nid))
        db().commit()
        log("network_edited", session["user"], "id=%d %s" % (nid, name))
        flash("Réseau modifié.")
    return redirect(url_for("networks"))

@app.route("/networks/<int:nid>/delete", methods=["POST"])
@role_required(*ADMINS)
def network_delete(nid):
    n = db().execute("SELECT * FROM networks WHERE id=?", (nid,)).fetchone()
    if n:
        db().execute("DELETE FROM devices WHERE network_id=?", (nid,))
        db().execute("DELETE FROM networks WHERE id=?", (nid,))
        db().commit()
        log("network_deleted", session["user"], "%s %s" % (n["name"], n["cidr"]))
        flash("Réseau supprimé.")
    return redirect(url_for("networks"))

# ───────────── Détection (limites réelles d'Android) ─────────────
def probe(ip):
    """Hôte considéré actif s'il accepte (0) ou refuse (ECONNREFUSED) une connexion TCP.
    Un hôte qui ne répond à aucun de ces ports (pare-feu) ne sera PAS détecté."""
    for p in SCAN_PORTS:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(0.35)
        try:
            r = s.connect_ex((ip, p))
            if r in (0, 111):
                return ip
        except OSError:
            pass
        finally:
            s.close()
    return None

def read_arp():
    """Lit /proc/net/arp. Souvent inaccessible/vide sur Android 10+ ; vérifié seulement si présent."""
    table = {}
    try:
        with open("/proc/net/arp") as f:
            next(f, None)
            for line in f:
                c = line.split()
                if len(c) >= 4 and c[3] != "00:00:00:00:00:00" and c[2] != "0x0":
                    table[c[0]] = c[3].lower()
    except OSError:
        pass
    return table

@app.route("/networks/<int:nid>/scan", methods=["POST"])
@role_required(*ADMINS)
def network_scan(nid):
    n = db().execute("SELECT * FROM networks WHERE id=?", (nid,)).fetchone()
    if not n:
        abort(404)
    net = ipaddress.ip_network(n["cidr"])           # plage ENREGISTRÉE uniquement
    hosts = [str(h) for h in (net.hosts() if net.num_addresses > 1 else [net.network_address])]
    if len(hosts) > SCAN_MAX_HOSTS:
        flash("Plage trop grande pour un scan (maximum %d adresses, soit /22)." % SCAN_MAX_HOSTS)
        return redirect(url_for("networks"))
    with ThreadPoolExecutor(max_workers=64) as ex:
        found = [ip for ip in ex.map(probe, hosts) if ip]
    arp, t = read_arp(), now()
    db().execute("UPDATE devices SET online=0 WHERE network_id=?", (nid,))
    known = {r[0] for r in db().execute("SELECT ip FROM devices WHERE network_id=?", (nid,))}
    for ip in found:
        if known and ip not in known:
            alert("warning", "Nouvel appareil %s sur le réseau %s" % (ip, n["name"]))
        mac = arp.get(ip)
        db().execute(
            "INSERT INTO devices(network_id,ip,mac,verified,online,first_seen,last_seen) "
            "VALUES(?,?,?,?,1,?,?) ON CONFLICT(network_id,ip) DO UPDATE SET "
            "online=1, last_seen=excluded.last_seen, "
            "mac=COALESCE(excluded.mac, mac), verified=MAX(verified, excluded.verified)",
            (nid, ip, mac, 1 if mac else 0, t, t))
    db().commit()
    log("scan", session["user"], "%s : %d appareil(s) détecté(s) sur %d adresses" % (n["cidr"], len(found), len(hosts)))
    flash("Scan terminé : %d appareil(s) détecté(s)." % len(found))
    return redirect(url_for("devices"))

# ───────────── v0.3.0 : comptes, appareils, consentement, LIVE MAP ─────────────
def setting(key, default=""):
    r = db().execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    return r["value"] if r else default
app.jinja_env.globals["signup_open"] = lambda: setting("allow_signup", "0") == "1"

def alert(level, message):
    db().execute("INSERT INTO alerts(ts,level,message) VALUES(?,?,?)", (now(), level, message))
    db().commit()

def purge_old():
    """Politique de conservation : supprime positions et estimations plus anciennes que retention_days."""
    con = sqlite3.connect(DB)
    row = con.execute("SELECT value FROM settings WHERE key='retention_days'").fetchone()
    days = int(row[0]) if row and str(row[0]).isdigit() else 30
    cut = (datetime.now(timezone.utc) - timedelta(days=days)).strftime("%Y-%m-%d %H:%M:%S")
    n = con.execute("DELETE FROM device_locations WHERE created_at<?", (cut,)).rowcount
    n += con.execute("DELETE FROM ip_estimates WHERE created_at<?", (cut,)).rowcount
    con.commit(); con.close()
    return n

def create_user(u, p, role):
    if not u or len(u) > 40:
        return "Nom d'utilisateur invalide."
    if len(p) < 10:
        return "Mot de passe trop court (10 caractères minimum)."
    try:
        db().execute("INSERT INTO users(username,password_hash,role,created_at) VALUES(?,?,?,?)",
                     (u, generate_password_hash(p), role, now()))
        db().commit()
    except sqlite3.IntegrityError:
        return "Ce nom d'utilisateur existe déjà."
    return None

@app.route("/register", methods=["GET", "POST"])
def register():
    if setting("allow_signup", "0") != "1":
        abort(404)
    if request.method == "POST":
        u = request.form.get("username", "").strip()
        err = create_user(u, request.form.get("password", ""), "client")
        if err:
            flash(err)
        else:
            log("client_registered", u)
            flash("Compte créé. Connectez-vous.")
            return redirect(url_for("login"))
    return render_template("register.html")

@app.route("/admin/users", methods=["GET", "POST"])
@role_required(*ADMINS)
def admin_users():
    if request.method == "POST":
        role = request.form.get("role", "client")
        if role not in ("client", "admin") or (role == "admin" and session["role"] != "super_admin"):
            abort(403)
        u = request.form.get("username", "").strip()
        err = create_user(u, request.form.get("password", ""), role)
        if err:
            flash(err)
        else:
            log("user_created", session["user"], "%s (%s)" % (u, role))
            flash("Compte créé.")
        return redirect(url_for("admin_users"))
    rows = db().execute("SELECT u.*, (SELECT COUNT(*) FROM client_devices d WHERE d.user_id=u.id) AS nb "
                        "FROM users u ORDER BY u.id").fetchall()
    return render_template("users.html", rows=rows)

@app.route("/admin/users/<int:uid>/toggle", methods=["POST"])
@role_required(*ADMINS)
def user_toggle(uid):
    t = db().execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
    if not t or t["id"] == session["uid"] or t["role"] == "super_admin":
        abort(403)
    if t["role"] == "admin" and session["role"] != "super_admin":
        abort(403)
    db().execute("UPDATE users SET active=? WHERE id=?", (0 if t["active"] else 1, uid))
    db().commit()
    log("user_toggled", session["user"], "%s -> %s" % (t["username"], "désactivé" if t["active"] else "activé"))
    return redirect(url_for("admin_users"))

@app.route("/admin/settings", methods=["GET", "POST"])
@role_required("super_admin")
def admin_settings():
    if request.method == "POST":
        days = request.form.get("retention_days", "30")
        days = days if days.isdigit() and 1 <= int(days) <= 3650 else "30"
        for k, v in (("allow_signup", "1" if request.form.get("allow_signup") else "0"),
                     ("retention_days", days)):
            db().execute("INSERT OR REPLACE INTO settings(key,value) VALUES(?,?)", (k, v))
        db().commit()
        log("settings_changed", session["user"], "inscription=%s conservation=%sj" % (
            setting("allow_signup"), days))
        if request.form.get("purge"):
            flash("%d enregistrement(s) purgé(s)." % purge_old())
        else:
            flash("Réglages enregistrés.")
        return redirect(url_for("admin_settings"))
    return render_template("settings.html", signup=setting("allow_signup") == "1",
                           days=setting("retention_days", "30"))

@app.route("/admin/devices")
@role_required(*ADMINS)
def admin_devices():
    rows = db().execute("SELECT d.*, u.username FROM client_devices d JOIN users u ON u.id=d.user_id "
                        "ORDER BY d.id DESC").fetchall()
    return render_template("admin_devices.html", rows=rows)

# ----- espace personnel : appareils et consentement -----
def my_device(did):
    d = db().execute("SELECT * FROM client_devices WHERE id=? AND user_id=?",
                     (did, session["uid"])).fetchone()
    if not d:
        abort(404)
    return d

@app.route("/me", methods=["GET", "POST"])
@login_required
def me():
    if request.method == "POST":
        name = request.form.get("name", "").strip()[:60]
        typ = request.form.get("device_type", "telephone")
        if not name or typ not in ("telephone", "ordinateur", "tablette", "autre"):
            flash("Nom ou type invalide.")
        else:
            cur = db().execute("INSERT INTO client_devices(user_id,name,device_type,os,created_at) VALUES(?,?,?,?,?)",
                               (session["uid"], name, typ, request.form.get("os", "").strip()[:40], now()))
            db().commit()
            log("device_registered", session["user"], name)
            return redirect(url_for("device_page", did=cur.lastrowid))
    rows = db().execute("SELECT * FROM client_devices WHERE user_id=? ORDER BY id DESC", (session["uid"],)).fetchall()
    return render_template("me.html", rows=rows)

@app.route("/me/devices/<int:did>")
@login_required
def device_page(did):
    d = my_device(did)
    gps = db().execute("SELECT * FROM device_locations WHERE device_id=? ORDER BY id DESC LIMIT 10", (did,)).fetchall()
    ip = db().execute("SELECT * FROM ip_estimates WHERE device_id=? ORDER BY id DESC LIMIT 1", (did,)).fetchone()
    return render_template("device.html", d=d, gps=gps, ip=ip)

@app.route("/me/devices/<int:did>/consent", methods=["POST"])
@login_required
def device_consent(did):
    my_device(did)
    kind, val = request.form.get("kind"), 1 if request.form.get("value") == "1" else 0
    if kind not in ("gps", "ip"):
        abort(400)
    db().execute("UPDATE client_devices SET share_%s=? WHERE id=?" % kind, (val, did))
    db().execute("INSERT INTO location_consents(device_id,kind,granted,ts) VALUES(?,?,?,?)", (did, kind, val, now()))
    db().commit()
    log("consent_" + ("granted" if val else "revoked"), session["user"], "appareil %d (%s)" % (did, kind))
    flash("Partage %s %s." % (kind.upper(), "activé" if val else "arrêté"))
    return redirect(url_for("device_page", did=did))

@app.route("/me/devices/<int:did>/purge", methods=["POST"])
@login_required
def device_purge(did):
    my_device(did)
    db().execute("DELETE FROM device_locations WHERE device_id=?", (did,))
    db().execute("DELETE FROM ip_estimates WHERE device_id=?", (did,))
    db().commit()
    log("data_deleted", session["user"], "positions de l'appareil %d" % did)
    flash("Vos positions enregistrées ont été supprimées.")
    return redirect(url_for("device_page", did=did))

@app.route("/me/devices/<int:did>/delete", methods=["POST"])
@login_required
def device_delete(did):
    my_device(did)
    db().execute("DELETE FROM client_devices WHERE id=?", (did,))
    db().commit()
    log("device_deleted", session["user"], "appareil %d" % did)
    return redirect(url_for("me"))

# ----- GPS (avec consentement) -----
@app.route("/api/v1/devices/<int:did>/gps", methods=["POST"])
def api_gps(did):
    if "uid" not in session:
        return jsonify(ok=False, error="Non connecté"), 401
    d = my_device(did)
    if not d["share_gps"]:
        return jsonify(ok=False, error="Partage GPS désactivé"), 403
    j = request.get_json(silent=True) or {}
    try:
        lat, lon, acc = float(j["lat"]), float(j["lon"]), float(j.get("accuracy") or 0)
    except (KeyError, TypeError, ValueError):
        return jsonify(ok=False, error="Données invalides"), 400
    if not all(map(math.isfinite, (lat, lon, acc))) or not (-90 <= lat <= 90 and -180 <= lon <= 180) or acc < 0:
        return jsonify(ok=False, error="Coordonnées invalides"), 400
    if db().execute("SELECT 1 FROM device_locations WHERE device_id=? AND created_at>datetime('now','-5 seconds')",
                    (did,)).fetchone():
        return jsonify(ok=False, error="Trop fréquent"), 429
    try:
        m = datetime.fromisoformat(str(j.get("measured_at", "")).replace("Z", "+00:00")).astimezone(timezone.utc)
        measured = m.strftime("%Y-%m-%d %H:%M:%S")
    except ValueError:
        measured = now()
    db().execute("INSERT INTO device_locations(device_id,lat,lon,accuracy,measured_at,created_at) VALUES(?,?,?,?,?,?)",
                 (did, lat, lon, acc, measured, now()))
    db().execute("UPDATE client_devices SET last_seen=? WHERE id=?", (now(), did))
    db().commit()
    return jsonify(ok=True)

# ----- Géolocalisation IP (approximative, avec consentement séparé) -----
def client_ip():
    if os.environ.get("EOG_TRUST_PROXY") == "1" and request.headers.get("X-Forwarded-For"):
        return request.headers["X-Forwarded-For"].split(",")[0].strip()
    return request.remote_addr or ""

def ip_geolocate(ip):
    """Service ipwho.is (HTTPS). Loopback = serveur sur l'appareil lui-même : on interroge sans IP."""
    try:
        addr = ipaddress.ip_address(ip)
    except ValueError:
        return None, "Adresse IP illisible."
    if addr.is_loopback:
        url = "https://ipwho.is/"
    elif addr.is_private:
        return None, "Adresse privée : estimation impossible."
    else:
        url = "https://ipwho.is/" + ip
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "EYE-OF-GOD"})
        data = json.load(urllib.request.urlopen(req, timeout=5))
    except Exception:
        return None, "Service de géolocalisation IP injoignable (Internet requis)."
    if not data.get("success") or data.get("latitude") is None:
        return None, "Aucune estimation disponible pour cette IP."
    return data, None

@app.route("/me/devices/<int:did>/ip-estimate", methods=["POST"])
@login_required
def device_ip_estimate(did):
    d = my_device(did)
    if not d["share_ip"]:
        abort(403)
    data, err = ip_geolocate(client_ip())
    if err:
        flash(err)
    else:
        db().execute("INSERT INTO ip_estimates(device_id,ip,lat,lon,city,region,country,created_at) VALUES(?,?,?,?,?,?,?,?)",
                     (did, data.get("ip"), data["latitude"], data["longitude"], data.get("city"),
                      data.get("region"), data.get("country"), now()))
        db().execute("UPDATE client_devices SET last_seen=? WHERE id=?", (now(), did))
        db().commit()
        flash("Estimation IP enregistrée (approximative).")
    return redirect(url_for("device_page", did=did))

# ----- LIVE MAP -----
@app.route("/map")
@login_required
def live_map():
    return render_template("map.html")

@app.route("/api/v1/map")
@login_required
def api_map():
    admin = session["role"] in ADMINS
    sql = "SELECT d.*, u.username FROM client_devices d JOIN users u ON u.id=d.user_id"
    rows = db().execute(sql + ("" if admin else " WHERE d.user_id=?"), () if admin else (session["uid"],)).fetchall()
    cut = (datetime.now(timezone.utc) - timedelta(minutes=5)).strftime("%Y-%m-%d %H:%M:%S")
    out = []
    for d in rows:
        gps = ip = None
        if d["share_gps"]:   # un administrateur ne voit RIEN si le client n'a pas activé le partage
            r = db().execute("SELECT lat,lon,accuracy,measured_at FROM device_locations WHERE device_id=? "
                             "ORDER BY id DESC LIMIT 1", (d["id"],)).fetchone()
            gps = dict(r) if r else None
        if d["share_ip"]:
            r = db().execute("SELECT lat,lon,city,region,country,created_at FROM ip_estimates WHERE device_id=? "
                             "ORDER BY id DESC LIMIT 1", (d["id"],)).fetchone()
            ip = dict(r) if r else None
        status = "inconnu" if not d["last_seen"] else ("en ligne" if d["last_seen"] >= cut else "hors ligne")
        out.append(dict(id=d["id"], name=d["name"], type=d["device_type"], os=d["os"], status=status,
                        last_seen=d["last_seen"], owner=d["username"] if admin else None,
                        share_gps=bool(d["share_gps"]), share_ip=bool(d["share_ip"]), gps=gps, ip=ip))
    return jsonify(devices=out)

if __name__ == "__main__":  # test hors Android
    migrate()
    app.run(host=os.environ.get("EOG_HOST", "127.0.0.1"), port=int(os.environ.get("EOG_PORT", "5000")))
