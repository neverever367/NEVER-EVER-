plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.chaquo.python")
}

android {
    namespace = "bj.eyeofgod.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "bj.eyeofgod.app"
        minSdk = 24            // Android 7.0 minimum (Android 9 OK)
        targetSdk = 34
        versionCode = 3
        versionName = "0.3.0"
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
    }

    // Clé de signature FIXE : indispensable pour que les mises à jour
    // s'installent par-dessus l'ancienne version sans perdre les données.
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

chaquopy {
    defaultConfig {
        version = "3.11"
        pip {
            install("flask==3.0.3")
            install("werkzeug==3.0.3")
            install("jinja2==3.1.4")
            install("markupsafe==2.1.3")
        }
    }
}
