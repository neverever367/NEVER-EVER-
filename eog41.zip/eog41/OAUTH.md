# Connexions sociales — guide de configuration (EYE OF GOD v0.4.0)

**État : code préparé, NON testé avec de vrais fournisseurs.** Les boutons n'apparaissent actifs que si les
identifiants sont présents sur le **serveur**. Les secrets ne vont JAMAIS dans l'APK ni dans GitHub.

## Prérequis importants
- Il faut un **serveur public en HTTPS** (domaine) : Google/Facebook/Microsoft/X refusent en pratique les
  adresses `http://127.0.0.1` d'une appli installée. L'APK seul (serveur local) ne peut donc PAS faire de connexion sociale.
- Définir `EOG_PUBLIC_URL=https://votre-domaine` ; l'URL de retour est `EOG_PUBLIC_URL/auth/<fournisseur>/callback`.
- Variables par fournisseur : `EOG_OAUTH_<NOM>_ID` et `EOG_OAUTH_<NOM>_SECRET` (NOM = GOOGLE, MICROSOFT, FACEBOOK, X).

| Fournisseur | Où créer l'application | Redirect URI à déclarer | Notes |
|---|---|---|---|
| Google | console.cloud.google.com > API et services > Identifiants > ID client OAuth (Application Web) | `…/auth/google/callback` | OpenID Connect, PKCE S256. Seul fournisseur dont l'e-mail est tenu pour vérifié (`email_verified`). |
| Microsoft | portal.azure.com > Microsoft Entra ID > Inscriptions d'applications | `…/auth/microsoft/callback` | Type Web. `EOG_OAUTH_MICROSOFT_TENANT` (défaut `common` : comptes perso + pro). E-mail non considéré vérifié. |
| Facebook | developers.facebook.com > Créer une app > Facebook Login | `…/auth/facebook/callback` | Autorisations `email`, `public_profile`. E-mail non considéré vérifié. L'app doit passer en mode « Live ». |
| X (Twitter) | developer.x.com > Projet > App > OAuth 2.0 | `…/auth/x/callback` | Type « Web App » (client confidentiel), PKCE. X ne fournit pas d'e-mail ici : compte créé sans e-mail. |
| Apple | **Non implémenté.** | — | Exige un compte Apple Developer payant (99 $/an), un Services ID, un domaine vérifié et un secret client signé ES256 (bibliothèque de chiffrement non incluse dans l'APK). |

## Règles appliquées
- Flux « code d'autorisation » + PKCE (S256) quand supporté, paramètre `state` vérifié (anti-CSRF).
- Le serveur échange le code et lit le profil lui-même (TLS) ; aucune confiance dans le navigateur.
- Aucune fusion automatique de comptes par e-mail : si l'e-mail existe déjà, il faut se connecter puis « Lier » depuis Profil.
- Impossible de retirer sa dernière méthode de connexion.
