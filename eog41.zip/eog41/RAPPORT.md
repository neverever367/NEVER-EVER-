# Rapport v0.4.0 (basé sur le ZIP v0.3.0 reçu — identique, vérifié fichier par fichier, à ma livraison v0.3.0)

## Audit (v0.3.0)
Flask embarqué (Chaquopy) + WebView, SQLite, migrations 1-3. Aucun bug bloquant trouvé. Défaut mineur : un `__pycache__` était dans le ZIP (retiré).
Point de vigilance corrigé : hachage par défaut `scrypt` (peut manquer sur Android) -> PBKDF2-SHA256 pour les nouveaux mots de passe ; les anciens hachages restent valides.

## Fonctionnel et TESTÉ (53 vérifications automatiques, Flask en local, pas sur téléphone)
Migration v3->v4 sans perte (comptes, appareils conservés, sauvegarde auto) · inscription nom/prénom/e-mail/mot de passe+confirmation · vérification e-mail (lien à usage unique) · connexion par e-mail ou nom · déconnexion · mot de passe oublié/réinitialisation · changement de mot de passe (ferme les autres sessions) · suppression de compte + données · verrouillage après N échecs (réglable) · suspension/réactivation (déconnexion immédiate) · sessions listées et révocables · rôles (propriétaire seul peut changer les rôles ; un client ne peut pas s'auto-promouvoir) · 12 pages client + 19 pages admin · notifications (diffusion admin) · EYE AI en mode démonstration · quiz (notation côté serveur) · isolation entre clients · Live Map/consentement/GPS (régression OK) · navigation latérale (ordinateur) + barre basse 5 entrées (mobile).

## Code préparé, nécessite une configuration (NON testé en réel)
Google, Microsoft, Facebook, X (logique OAuth testée avec fournisseurs SIMULÉS uniquement) · envoi d'e-mails SMTP (sinon boîte d'envoi locale visible du propriétaire) · EYE AI branchée à une API compatible OpenAI.

## Non implémenté
Connexion Apple · authentification renforcée (2FA) · synchronisation SQLite<->PostgreSQL · PWA installable · traceroute/Nmap · rendu visuel vérifié sur un vrai écran (CSS écrit, non vu) · compilation Android (jamais exécutée ici).

## Limites à connaître
- L'APK est un serveur local mono-téléphone : les connexions sociales et les clients sur d'autres appareils exigent un serveur HTTPS (voir OAUTH.md).
- Les fonds de carte et Leaflet demandent Internet.

## Retour arrière
Réinstaller l'APK v0.3.0 par-dessus n'est PAS possible (versionCode plus bas). Sauvegardes avant migration : dossier `data/backups/` de l'appli.
