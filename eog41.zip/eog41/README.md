# EYE OF GOD — v0.4.0 (APK Android autonome) — correctif 0.4.1 : voir RAPPORT_CORRECTION_v0.4.1.md

Application Android qui embarque son propre serveur (Python/Flask via Chaquopy) et sa base SQLite.
Aucun Termux, Pydroid ou terminal nécessaire. Données dans l'espace privé de l'application.

## Obtenir l'APK depuis le téléphone
1. Sur github.com : **New repository** → nom `eyeofgod` → *Create repository*.
2. **Add file → Upload files** : envoyez le fichier ZIP tel quel (sans le décompresser).
3. **Add file → Create new file** : nom `.github/workflows/build.yml`, collez le workflow fourni dans la conversation, *Commit changes*.
4. Onglet **Actions** → « Compiler EYE OF GOD (APK) » → attendre la coche verte (10 à 15 min la 1ʳᵉ fois).
   Si elle ne démarre pas seule : *Run workflow*.
5. Ouvrir l'exécution → section **Artifacts** → télécharger `EYE-OF-GOD-apk` (ZIP contenant `app-debug.apk`).
6. Décompresser, ouvrir `app-debug.apk`, autoriser « sources inconnues » si demandé, installer.

## Première utilisation
Ouvrir EYE OF GOD → écran « Première configuration » → créer l'administrateur → se connecter.

## Mises à jour sans perte de données
- Remplacez les fichiers modifiés dans GitHub, relancez la compilation, installez le nouvel APK **par-dessus**
  (ne désinstallez jamais l'ancien : cela effacerait les données).
- La clé de signature (`app/debug.keystore`) est fixe : c'est ce qui permet la mise à jour par-dessus.
- Au démarrage, la base est sauvegardée puis migrée (`PRAGMA user_version`), sans DROP.
  Sauvegardes dans l'espace privé de l'appli : `data/backups/`.

## Limites
- Détection par connexions TCP : pas de ping ICMP, pas de Nmap, MAC souvent indisponible sans root.
- APK « debug » : pour usage personnel, pas pour le Play Store.
- Le serveur écoute sur 127.0.0.1 uniquement (non joignable depuis le réseau).

## Nouveautés v0.3.0 (phase 1)
- Rôles : super administrateur (propriétaire), administrateur, client. Le 1er administrateur existant devient propriétaire.
- Espace client : enregistrement d'appareils, consentement GPS et IP séparés (désactivés par défaut), suppression de ses données.
- LIVE MAP (Leaflet + OpenStreetMap) : GPS (précis) et estimation IP (approximative) clairement distingués ; liste « Position indisponible ».
- Un administrateur ne voit une position que si le client a activé le partage ; il ne peut pas l'activer lui-même.
- Conservation configurable (Réglages) ; migration 3 avec sauvegarde automatique.

## Important : clients sur d'autres appareils
Le serveur de l'APK n'écoute que sur ce téléphone (127.0.0.1). Pour de vrais clients sur leurs propres appareils,
il faut héberger la même application sur un serveur (Windows/Linux) : `pip install flask`, puis
`EOG_HOST=0.0.0.0 EOG_HTTPS=1 python app.py` derrière HTTPS (reverse proxy). Non testé ici.

## Pas encore fait (prochaines phases)
EYE AI, jeux/quiz, diagnostics ping/DNS/traceroute/Nmap, synchronisation hybride (sync_queue), sauvegarde/restauration depuis l'interface, PostgreSQL.

## v0.4.0 (voir RAPPORT.md et OAUTH.md)
Refonte Midnight Blue, navigation latérale (ordinateur) / barre basse 5 entrées + « Plus » (mobile), comptes complets
(e-mail, vérification, réinitialisation, sessions), connexions sociales préparées, EYE AI (démo), jeux (2 quiz), administration étendue.
Mise à jour : installer l'APK par-dessus la v0.3.0 (même signature) ; la base est migrée avec sauvegarde.
