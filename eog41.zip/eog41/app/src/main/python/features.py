"""EYE OF GOD v0.4.0 — modules ajoutés : navigation, comptes, e-mail, connexions sociales (OAuth2/OIDC),
sessions, notifications, EYE AI, jeux, administration. Importé par app.py."""
import os, re, json, base64, hashlib, hmac, secrets, smtplib, urllib.parse, urllib.request
from email.message import EmailMessage
from datetime import datetime, timezone, timedelta
from flask import request, session, redirect, url_for, flash, render_template, abort
from werkzeug.security import check_password_hash
from app import (app, db, now, log, login_required, role_required, ADMINS, setting,
                 hash_pw, start_session, VERSION)

# ───────────── Icônes et navigation ─────────────
ICONS = {
 "home": "M3 11l9-8 9 8v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z",
 "map": "M9 4L3 6v14l6-2 6 2 6-2V4l-6 2z M9 4v14 M15 6v14",
 "device": "M7 2h10a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V3a1 1 0 0 1 1-1z M11 18h2",
 "user": "M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2 M12 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8z",
 "users": "M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2 M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8z M23 21v-2a4 4 0 0 0-3-3.9 M16 3.1a4 4 0 0 1 0 7.8",
 "grid": "M4 4h6v6H4z M14 4h6v6h-6z M4 14h6v6H4z M14 14h6v6h-6z",
 "bell": "M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9 M13.7 21a2 2 0 0 1-3.4 0",
 "shield": "M12 2l8 3v7c0 5-3.5 8.5-8 10-4.5-1.5-8-5-8-10V5z",
 "bot": "M12 8V4 M8 4h8 M5 8h14a1 1 0 0 1 1 1v9a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V9a1 1 0 0 1 1-1z M9 13h.01 M15 13h.01",
 "game": "M6 12h4 M8 10v4 M15 13h.01 M18 11h.01 M17.3 5H6.7a4 4 0 0 0-3.9 3.2l-1.6 8A2.5 2.5 0 0 0 5.6 19l2-2h8.8l2 2a2.5 2.5 0 0 0 4.4-2.8l-1.6-8A4 4 0 0 0 17.3 5z",
 "list": "M8 6h13 M8 12h13 M8 18h13 M3 6h.01 M3 12h.01 M3 18h.01",
 "network": "M5 12a7 7 0 0 1 14 0 M2 9a11 11 0 0 1 20 0 M9 15a3 3 0 0 1 6 0 M12 19h.01",
 "sliders": "M4 21v-7 M4 10V3 M12 21v-9 M12 8V3 M20 21v-5 M20 12V3 M1 14h6 M9 8h6 M17 16h6",
 "logout": "M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4 M16 17l5-5-5-5 M21 12H9",
 "lock": "M5 11h14v10H5z M8 11V7a4 4 0 0 1 8 0v4",
 "clock": "M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20z M12 6v6l4 2",
 "menu": "M3 12h18 M3 6h18 M3 18h18",
}
CLIENT_NAV = [("dashboard", "Accueil", "home"), ("live_map", "Live Map", "map"), ("me", "Mes appareils", "device"),
              ("history", "Historique", "clock"), ("ai", "EYE AI", "bot"), ("games", "Jeux", "game"),
              ("notifications", "Notifications", "bell"), ("profile", "Profil", "user"),
              ("privacy", "Confidentialité", "lock"), ("sessions", "Sessions", "shield"),
              ("settings", "Paramètres", "sliders")]
ADMIN_NAV = [("dashboard", "Tableau de bord", "home"), ("live_map", "Live Map", "map"),
             ("admin_users", "Clients et comptes", "users"), ("admin_devices", "Appareils", "device"),
             ("networks", "Inventaire réseau", "network"), ("devices", "Détectés (réseau)", "network"),
             ("journal", "Connexions", "clock", {"login": 1}), ("journal", "Journaux", "list"),
             ("admin_notifications", "Notifications", "bell"), ("admin_ai", "EYE AI", "bot"),
             ("admin_games", "Jeux", "game"), ("admin_roles", "Rôles", "shield"),
             ("admin_security", "Sécurité", "lock"), ("admin_settings", "Configuration", "sliders")]
ADMIN_PERSONAL = [("me", "Mes appareils", "device"), ("profile", "Profil", "user"),
                  ("sessions", "Sessions", "clock"), ("settings", "Paramètres", "sliders")]

def _items(raw):
    out = []
    for t in raw:
        ep, label, ic = t[:3]
        kw = t[3] if len(t) > 3 else {}
        if ep == "admin_settings" and session.get("role") != "super_admin":
            continue
        act = request.endpoint == ep and all(request.args.get(k) for k in kw) and \
              (bool(kw) or not request.args.get("login"))
        out.append(dict(ep=ep, label=label, icon=ic, kw=kw, active=act))
    return out

@app.context_processor
def inject():
    ctx = dict(ICONS=ICONS)
    if "uid" in session:
        admin = session.get("role") in ADMINS
        nav = _items(ADMIN_NAV if admin else CLIENT_NAV)
        personal = _items(ADMIN_PERSONAL) if admin else []
        ctx.update(nav=nav, personal=personal, is_admin=admin,
                   dev_ep="admin_devices" if admin else "me",
                   unread=db().execute("SELECT COUNT(*) FROM notifications WHERE user_id=? AND read=0",
                                       (session["uid"],)).fetchone()[0],
                   page_title=next((i["label"] for i in nav + personal if i["active"]), "EYE OF GOD"))
    return ctx

@app.route("/more")
@login_required
def more():
    return render_template("more.html")

# ───────────── Utilitaires : jetons, e-mail, notifications ─────────────
def sha(t): return hashlib.sha256(t.encode()).hexdigest()
def notify(uid, msg, level="info"):
    db().execute("INSERT INTO notifications(user_id,ts,level,message) VALUES(?,?,?,?)", (uid, now(), level, msg))
    db().commit()
def public_url(): return (os.environ.get("EOG_PUBLIC_URL") or request.host_url).rstrip("/")

def make_token(uid, kind, hours):
    t = secrets.token_urlsafe(32)
    exp = (datetime.now(timezone.utc) + timedelta(hours=hours)).strftime("%Y-%m-%d %H:%M:%S")
    db().execute("INSERT INTO email_tokens(user_id,kind,token_hash,expires_at) VALUES(?,?,?,?)", (uid, kind, sha(t), exp))
    db().commit()
    return t

def get_token(t, kind, consume):
    r = db().execute("SELECT * FROM email_tokens WHERE token_hash=? AND kind=? AND used=0 AND expires_at>?",
                     (sha(t), kind, now())).fetchone()
    if r and consume:
        db().execute("UPDATE email_tokens SET used=1 WHERE id=?", (r["id"],)); db().commit()
    return r

def send_mail(to, subject, body):
    """SMTP si EOG_SMTP_HOST est défini ; sinon dépôt dans la boîte d'envoi locale (voir Sécurité)."""
    host = os.environ.get("EOG_SMTP_HOST")
    if host:
        try:
            m = EmailMessage(); m["From"] = os.environ.get("EOG_SMTP_FROM", "no-reply@eyeofgod.local")
            m["To"] = to; m["Subject"] = subject; m.set_content(body)
            with smtplib.SMTP(host, int(os.environ.get("EOG_SMTP_PORT", "587")), timeout=10) as s:
                s.starttls()
                if os.environ.get("EOG_SMTP_USER"):
                    s.login(os.environ["EOG_SMTP_USER"], os.environ.get("EOG_SMTP_PASSWORD", ""))
                s.send_message(m)
            return "envoyé par e-mail"
        except Exception:
            pass
    db().execute("INSERT INTO outbox(ts,to_addr,subject,body) VALUES(?,?,?,?)", (now(), to, subject, body))
    db().commit()
    return "déposé dans la boîte d'envoi locale (SMTP non configuré : demandez le lien à l'administrateur)"

def send_verify(uid, email):
    t = make_token(uid, "verify", 24)
    return send_mail(email, "EYE OF GOD — vérifiez votre adresse", "Ouvrez ce lien (valable 24 h) :\n%s/verify/%s\n" % (public_url(), t))

# ───────────── Inscription, e-mail, mot de passe ─────────────
EMAIL_RE = re.compile(r"^[^@\s]{1,64}@[^@\s]{1,200}\.[^@\s]{2,}$")

@app.route("/register", methods=["GET", "POST"])
def register():
    if setting("allow_signup", "0") != "1":
        abort(404)
    if request.method == "POST":
        f = {k: request.form.get(k, "").strip() for k in ("first_name", "last_name", "email")}
        p, p2, email = request.form.get("password", ""), request.form.get("password2", ""), f["email"].lower()
        if not f["first_name"] or not f["last_name"]:
            flash("Nom et prénom obligatoires.")
        elif not EMAIL_RE.match(email):
            flash("Adresse e-mail invalide.")
        elif len(p) < 10:
            flash("Mot de passe trop court (10 caractères minimum).")
        elif p != p2:
            flash("Les deux mots de passe ne correspondent pas.")
        elif db().execute("SELECT 1 FROM users WHERE username=? OR lower(email)=?", (email, email)).fetchone():
            flash("Impossible de créer ce compte avec cette adresse.")
        else:
            cur = db().execute("INSERT INTO users(username,password_hash,role,created_at,email,first_name,last_name) "
                               "VALUES(?,?,'client',?,?,?,?)", (email, hash_pw(p), now(), email, f["first_name"][:60], f["last_name"][:60]))
            db().commit()
            how = send_verify(cur.lastrowid, email)
            log("client_registered", email)
            flash("Compte créé. Lien de vérification : %s." % how)
            return redirect(url_for("login"))
    return render_template("register.html")

@app.route("/verify/<token>")
def verify(token):
    r = get_token(token, "verify", True)
    if r:
        db().execute("UPDATE users SET email_verified=1 WHERE id=?", (r["user_id"],)); db().commit()
        log("email_verified", None, "user %d" % r["user_id"])
        flash("Adresse e-mail vérifiée.")
    else:
        flash("Lien invalide ou expiré.")
    return redirect(url_for("login"))

@app.route("/profile/resend", methods=["POST"])
@login_required
def resend_verify():
    u = db().execute("SELECT * FROM users WHERE id=?", (session["uid"],)).fetchone()
    if u["email"] and not u["email_verified"]:
        flash("Lien de vérification : %s." % send_verify(u["id"], u["email"]))
    return redirect(url_for("profile"))

@app.route("/forgot", methods=["GET", "POST"])
def forgot():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        u = db().execute("SELECT * FROM users WHERE lower(email)=? AND active=1", (email,)).fetchone() if email else None
        if u:
            t = make_token(u["id"], "reset", 1)
            send_mail(email, "EYE OF GOD — réinitialisation du mot de passe",
                      "Ouvrez ce lien (valable 1 h) :\n%s/reset/%s\nSi vous n'êtes pas à l'origine de cette demande, ignorez ce message.\n" % (public_url(), t))
            log("password_reset_requested", u["username"])
        flash("Si cette adresse existe, un lien de réinitialisation a été préparé (e-mail, ou boîte d'envoi locale si SMTP non configuré).")
        return redirect(url_for("login"))
    return render_template("forgot.html")

@app.route("/reset/<token>", methods=["GET", "POST"])
def reset(token):
    if not get_token(token, "reset", False):
        flash("Lien invalide ou expiré.")
        return redirect(url_for("login"))
    if request.method == "POST":
        p, p2 = request.form.get("password", ""), request.form.get("password2", "")
        if len(p) < 10 or p != p2:
            flash("Mot de passe trop court ou différent de la confirmation.")
        else:
            r = get_token(token, "reset", True)
            db().execute("UPDATE users SET password_hash=?, pw_set=1 WHERE id=?", (hash_pw(p), r["user_id"]))
            db().execute("UPDATE user_sessions SET revoked=1 WHERE user_id=?", (r["user_id"],))
            db().commit()
            notify(r["user_id"], "Votre mot de passe a été réinitialisé.", "warning")
            log("password_reset_done", None, "user %d" % r["user_id"])
            flash("Mot de passe modifié. Connectez-vous.")
            return redirect(url_for("login"))
    return render_template("reset.html")

# ───────────── Profil, paramètres, sessions, historique, confidentialité ─────────────
def me_row(): return db().execute("SELECT * FROM users WHERE id=?", (session["uid"],)).fetchone()

@app.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    u = me_row()
    if request.method == "POST":
        fn, ln = request.form.get("first_name", "").strip()[:60], request.form.get("last_name", "").strip()[:60]
        email = request.form.get("email", "").strip().lower()
        if email and not EMAIL_RE.match(email):
            flash("Adresse e-mail invalide.")
        elif email and email != (u["email"] or "") and db().execute(
                "SELECT 1 FROM users WHERE lower(email)=? AND id!=?", (email, u["id"])).fetchone():
            flash("Cette adresse est déjà utilisée.")
        else:
            changed = email != (u["email"] or "")
            db().execute("UPDATE users SET first_name=?, last_name=?, email=?, email_verified=? WHERE id=?",
                         (fn, ln, email or None, 0 if changed else u["email_verified"], u["id"]))
            db().commit()
            if changed and email:
                flash("Profil mis à jour. Vérification : %s." % send_verify(u["id"], email))
            else:
                flash("Profil mis à jour.")
        return redirect(url_for("profile"))
    linked = {r["provider"]: r for r in db().execute("SELECT * FROM social_accounts WHERE user_id=?", (u["id"],))}
    return render_template("profile.html", u=u, linked=linked, providers=provider_list())

@app.route("/settings")
@login_required
def settings():
    return render_template("settings_user.html", u=me_row())

@app.route("/settings/password", methods=["POST"])
@login_required
def change_password():
    u = me_row()
    cur, p, p2 = (request.form.get(k, "") for k in ("current", "password", "password2"))
    if u["pw_set"] and not check_password_hash(u["password_hash"], cur):
        flash("Mot de passe actuel incorrect.")
    elif len(p) < 10 or p != p2:
        flash("Nouveau mot de passe trop court ou différent de la confirmation.")
    else:
        db().execute("UPDATE users SET password_hash=?, pw_set=1 WHERE id=?", (hash_pw(p), u["id"]))
        db().execute("UPDATE user_sessions SET revoked=1 WHERE user_id=? AND sid!=?", (u["id"], session["sid"]))
        db().commit()
        notify(u["id"], "Votre mot de passe a été modifié ; les autres sessions ont été fermées.", "warning")
        log("password_changed", u["username"])
        flash("Mot de passe modifié.")
    return redirect(url_for("settings"))

@app.route("/settings/delete", methods=["POST"])
@login_required
def delete_account():
    u = me_row()
    if u["role"] == "super_admin":
        flash("Le compte propriétaire ne peut pas être supprimé ici.")
        return redirect(url_for("settings"))
    if u["pw_set"] and not check_password_hash(u["password_hash"], request.form.get("password", "")):
        flash("Mot de passe incorrect : suppression annulée.")
        return redirect(url_for("settings"))
    db().execute("DELETE FROM client_devices WHERE user_id=?", (u["id"],))   # + positions et consentements (cascade)
    db().execute("DELETE FROM users WHERE id=?", (u["id"],))                  # + sessions, comptes liés, notifications, IA, jeux
    db().commit()
    log("account_deleted", u["username"])
    session.clear()
    flash("Compte et données supprimés.")
    return redirect(url_for("login"))

@app.route("/sessions", methods=["GET", "POST"])
@login_required
def sessions():
    if request.method == "POST":
        sid = request.form.get("sid")
        if sid == "others":
            db().execute("UPDATE user_sessions SET revoked=1 WHERE user_id=? AND sid!=?", (session["uid"], session["sid"]))
        else:
            db().execute("UPDATE user_sessions SET revoked=1 WHERE user_id=? AND sid=? AND sid!=?", (session["uid"], sid, session["sid"]))
        db().commit(); log("session_revoked", session["user"])
        flash("Session(s) fermée(s).")
        return redirect(url_for("sessions"))
    rows = db().execute("SELECT * FROM user_sessions WHERE user_id=? AND revoked=0 ORDER BY last_seen DESC", (session["uid"],)).fetchall()
    return render_template("sessions.html", rows=rows)

@app.route("/history")
@login_required
def history():
    u = me_row()
    rows = db().execute("SELECT * FROM security_logs WHERE username IN (?,?) AND event IN ('login_ok','login_failed','logout') "
                        "ORDER BY id DESC LIMIT 50", (u["username"], u["email"] or u["username"])).fetchall()
    return render_template("history.html", rows=rows)

@app.route("/privacy")
@login_required
def privacy():
    rows = db().execute("SELECT * FROM client_devices WHERE user_id=? ORDER BY id", (session["uid"],)).fetchall()
    return render_template("privacy.html", rows=rows)

@app.route("/notifications", methods=["GET", "POST"])
@login_required
def notifications():
    if request.method == "POST":
        db().execute("UPDATE notifications SET read=1 WHERE user_id=?", (session["uid"],)); db().commit()
        return redirect(url_for("notifications"))
    rows = db().execute("SELECT * FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 50", (session["uid"],)).fetchall()
    return render_template("notifications.html", rows=rows)

# ───────────── Connexions sociales (OAuth 2.0 / OpenID Connect, code + PKCE + state) ─────────────
# Secrets UNIQUEMENT dans des variables d'environnement du serveur : EOG_OAUTH_<FOURNISSEUR>_ID / _SECRET.
PROVIDERS = {
 "google": dict(label="Google", pkce=True, scope="openid email profile",
   auth="https://accounts.google.com/o/oauth2/v2/auth", token="https://oauth2.googleapis.com/token",
   info="https://openidconnect.googleapis.com/v1/userinfo"),
 "microsoft": dict(label="Microsoft", pkce=True, scope="openid email profile",
   auth="https://login.microsoftonline.com/{tenant}/oauth2/v2.0/authorize",
   token="https://login.microsoftonline.com/{tenant}/oauth2/v2.0/token",
   info="https://graph.microsoft.com/oidc/userinfo"),
 "facebook": dict(label="Facebook", pkce=False, scope="email public_profile",
   auth="https://www.facebook.com/v19.0/dialog/oauth", token="https://graph.facebook.com/v19.0/oauth/access_token",
   info="https://graph.facebook.com/me?fields=id,name,email"),
 "x": dict(label="X (Twitter)", pkce=True, scope="users.read tweet.read", basic=True,
   auth="https://twitter.com/i/oauth2/authorize", token="https://api.twitter.com/2/oauth2/token",
   info="https://api.twitter.com/2/users/me"),
}
def creds(p):
    k = p.upper()
    return os.environ.get("EOG_OAUTH_%s_ID" % k), os.environ.get("EOG_OAUTH_%s_SECRET" % k)
def provider_list():
    out = [dict(code=c, label=v["label"], ready=all(creds(c))) for c, v in PROVIDERS.items()]
    out.append(dict(code="apple", label="Apple", ready=False, note="non implémenté (compte Apple Developer payant + clé ES256 requis)"))
    return out
def pu(p, key):
    return PROVIDERS[p][key].replace("{tenant}", os.environ.get("EOG_OAUTH_MICROSOFT_TENANT", "common"))
def redirect_uri(p): return "%s/auth/%s/callback" % (public_url(), p)

def http_json(url, data=None, headers=None):
    body = urllib.parse.urlencode(data).encode() if data is not None else None
    req = urllib.request.Request(url, data=body, headers=headers or {})
    with urllib.request.urlopen(req, timeout=10) as r:
        return json.load(r)

@app.route("/auth/<p>/start")
def oauth_start(p):
    if p not in PROVIDERS or not all(creds(p)):
        flash("Connexion %s non configurée sur ce serveur." % p)
        return redirect(url_for("login"))
    state, verifier = secrets.token_urlsafe(24), secrets.token_urlsafe(48)
    session["oauth"] = dict(state=state, verifier=verifier, p=p, link=("uid" in session and request.args.get("link") == "1"))
    q = dict(response_type="code", client_id=creds(p)[0], redirect_uri=redirect_uri(p), scope=PROVIDERS[p]["scope"], state=state)
    if PROVIDERS[p]["pkce"]:
        q.update(code_challenge=base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b"=").decode(),
                 code_challenge_method="S256")
    return redirect(pu(p, "auth") + "?" + urllib.parse.urlencode(q))

def normalize(p, info):
    """-> (subject, email, email_vérifié_par_le_fournisseur, nom). Seul Google garantit email_verified."""
    if p == "google":
        return info.get("sub"), info.get("email"), info.get("email_verified") is True, info.get("name", "")
    if p == "microsoft":
        return info.get("sub"), info.get("email"), False, info.get("name", "")
    if p == "facebook":
        return info.get("id"), info.get("email"), False, info.get("name", "")
    d = info.get("data", {})
    return d.get("id"), None, False, d.get("name", "")

@app.route("/auth/<p>/callback")
def oauth_callback(p):
    st = session.pop("oauth", None)
    if p not in PROVIDERS or not st or st["p"] != p or not hmac.compare_digest(st["state"], request.args.get("state", "")):
        flash("Connexion refusée : état OAuth invalide ou expiré.")
        return redirect(url_for("login"))
    if request.args.get("error") or not request.args.get("code"):
        flash("Connexion annulée ou refusée par le fournisseur.")
        return redirect(url_for("login"))
    cid, secret = creds(p)
    try:
        data = dict(grant_type="authorization_code", code=request.args["code"], redirect_uri=redirect_uri(p))
        hdr = {"Accept": "application/json"}
        if PROVIDERS[p].get("basic"):
            hdr["Authorization"] = "Basic " + base64.b64encode(("%s:%s" % (cid, secret)).encode()).decode()
        else:
            data.update(client_id=cid, client_secret=secret)
        if PROVIDERS[p]["pkce"]:
            data["code_verifier"] = st["verifier"]
        tok = http_json(pu(p, "token"), data, hdr)
        info = http_json(pu(p, "info"), None, {"Authorization": "Bearer " + tok["access_token"], "Accept": "application/json"})
        subject, email, verified, name = normalize(p, info)
        subject = str(subject) if subject else None
    except Exception:
        flash("Échec de la communication avec le fournisseur.")
        return redirect(url_for("login"))
    if not subject:
        flash("Réponse du fournisseur incomplète.")
        return redirect(url_for("login"))
    return finish_social(p, subject, (email or "").lower() or None, verified, name, st["link"])

def finish_social(p, subject, email, verified, name, link):
    sa = db().execute("SELECT * FROM social_accounts WHERE provider=? AND subject=?", (p, subject)).fetchone()
    if link and "uid" in session:
        if sa and sa["user_id"] != session["uid"]:
            flash("Ce compte %s est déjà lié à un autre utilisateur." % p)
        elif not sa:
            db().execute("INSERT INTO social_accounts(user_id,provider,subject,email,created_at) VALUES(?,?,?,?,?)",
                         (session["uid"], p, subject, email, now())); db().commit()
            notify(session["uid"], "Méthode de connexion ajoutée : %s." % p); log("social_linked", session["user"], p)
            flash("Compte %s lié." % p)
        return redirect(url_for("profile"))
    if sa:
        u = db().execute("SELECT * FROM users WHERE id=?", (sa["user_id"],)).fetchone()
    else:
        if email and db().execute("SELECT 1 FROM users WHERE lower(email)=?", (email,)).fetchone():
            # jamais de fusion automatique par e-mail (risque de prise de contrôle de compte)
            flash("Un compte existe déjà avec cette adresse. Connectez-vous avec votre mot de passe, puis liez %s depuis Profil." % p)
            return redirect(url_for("login"))
        if setting("allow_signup", "0") != "1":
            flash("Les inscriptions sont fermées.")
            return redirect(url_for("login"))
        fn, _, ln = (name or "").partition(" ")
        cur = db().execute("INSERT INTO users(username,password_hash,role,created_at,email,first_name,last_name,email_verified,pw_set) "
                           "VALUES(?,?,'client',?,?,?,?,?,0)",
                           ("%s_%s" % (p, subject)[:60], hash_pw(secrets.token_urlsafe(32)), now(),
                            email if verified else None, fn[:60], ln[:60], 1 if verified else 0))
        db().execute("INSERT INTO social_accounts(user_id,provider,subject,email,created_at) VALUES(?,?,?,?,?)",
                     (cur.lastrowid, p, subject, email, now())); db().commit()
        u = db().execute("SELECT * FROM users WHERE id=?", (cur.lastrowid,)).fetchone()
    if not u["active"]:
        flash("Compte suspendu.")
        return redirect(url_for("login"))
    start_session(u)
    return redirect(url_for("dashboard"))

@app.route("/profile/unlink/<p>", methods=["POST"])
@login_required
def unlink(p):
    u = me_row()
    n = db().execute("SELECT COUNT(*) FROM social_accounts WHERE user_id=?", (u["id"],)).fetchone()[0]
    if n == 0 or (not u["pw_set"] and n < 2):
        flash("Impossible : ce serait votre dernière méthode de connexion. Définissez d'abord un mot de passe (Paramètres).")
    else:
        db().execute("DELETE FROM social_accounts WHERE user_id=? AND provider=?", (u["id"], p)); db().commit()
        log("social_unlinked", u["username"], p); flash("Méthode de connexion retirée.")
    return redirect(url_for("profile"))

# ───────────── EYE AI (fournisseur compatible OpenAI via variables d'environnement serveur) ─────────────
SYSTEM = ("Tu es EYE AI, assistant de la plateforme EYE OF GOD. Réponds en français, simplement, sur l'usage de "
          "l'application, la sécurité numérique et les réseaux. Ne demande jamais de mot de passe.")
DEMO = [("mot de passe|password|mdp", "Choisissez une phrase longue et unique (10+ caractères), différente pour chaque site, et activez la double authentification quand elle existe."),
        ("phishing|hame", "Le phishing imite un service connu pour voler vos informations. Ne cliquez pas sur un lien inattendu : ouvrez le site vous-même et vérifiez l'expéditeur."),
        ("gps|position|localis", "Le partage GPS est désactivé par défaut. Vous l'activez appareil par appareil (Mes appareils), vous pouvez l'arrêter à tout moment et supprimer vos positions."),
        ("ip\\b|adresse ip", "Une adresse IP identifie un appareil sur un réseau. La localisation par IP est seulement approximative (ville/région), jamais un GPS précis."),
        ("mac", "L'adresse MAC identifie une carte réseau sur le réseau local. Android la masque souvent : EYE OF GOD affiche « indisponible » si elle n'est pas lisible."),
        ("dns", "Le DNS traduit un nom de site (exemple.com) en adresse IP."),
        ("wifi|wi-fi", "Préférez WPA2/WPA3, changez le mot de passe du routeur par défaut et désactivez WPS."),
        ("alerte|notification", "Les alertes signalent un événement (nouvel appareil, changement de mot de passe, connexion). Vérifiez qu'elles correspondent à vos actions ; sinon changez votre mot de passe et fermez vos sessions."),
        ("session", "Dans Sessions, vous voyez où votre compte est connecté et pouvez fermer les sessions inconnues."),
        ("carte|map", "La Live Map affiche uniquement les appareils dont le propriétaire a activé le partage. Sans position : « Position indisponible ».")]

def eye_reply(history, text):
    url, key = os.environ.get("EOG_AI_URL"), os.environ.get("EOG_AI_KEY")
    if url and key:
        try:
            body = json.dumps({"model": os.environ.get("EOG_AI_MODEL", ""), "max_tokens": 500,
                               "messages": [{"role": "system", "content": SYSTEM}] + history + [{"role": "user", "content": text}]}).encode()
            req = urllib.request.Request(url, data=body, headers={"Content-Type": "application/json", "Authorization": "Bearer " + key})
            return json.load(urllib.request.urlopen(req, timeout=20))["choices"][0]["message"]["content"], "ia"
        except Exception:
            pass
    low = text.lower()
    for pat, ans in DEMO:
        if re.search(pat, low):
            return ans, "demo"
    return "Mode démonstration : je connais quelques sujets (mots de passe, phishing, GPS, IP, MAC, DNS, Wi-Fi, alertes, sessions, carte). Reformulez avec l'un de ces mots.", "demo"

@app.route("/ai", methods=["GET", "POST"])
@login_required
def ai():
    uid = session["uid"]
    if request.method == "POST":
        text = request.form.get("message", "").strip()[:1000]
        if text:
            hist = [{"role": r["role"], "content": r["content"]} for r in db().execute(
                "SELECT role,content FROM ai_messages WHERE user_id=? ORDER BY id DESC LIMIT 10", (uid,))][::-1]
            ans, _ = eye_reply(hist, text)
            db().execute("INSERT INTO ai_messages(user_id,role,content,ts) VALUES(?,?,?,?)", (uid, "user", text, now()))
            db().execute("INSERT INTO ai_messages(user_id,role,content,ts) VALUES(?,?,?,?)", (uid, "assistant", ans, now()))
            db().commit()
        return redirect(url_for("ai"))
    msgs = db().execute("SELECT * FROM ai_messages WHERE user_id=? ORDER BY id DESC LIMIT 40", (uid,)).fetchall()[::-1]
    return render_template("ai.html", msgs=msgs, live=bool(os.environ.get("EOG_AI_URL") and os.environ.get("EOG_AI_KEY")))

# ───────────── Jeux ─────────────
QUIZ = {
 "quiz-reseau": [("Que signifie DNS ?", ["Système de noms de domaine", "Données Numériques Sécurisées", "Dynamic Network Server"], 0),
                 ("Quelle plage d'adresses est privée ?", ["8.8.8.0/24", "192.168.1.0/24", "41.0.0.0/8"], 1),
                 ("Port par défaut du HTTPS ?", ["80", "22", "443"], 2),
                 ("Une adresse MAC identifie…", ["une carte réseau", "un site web", "un mot de passe"], 0),
                 ("Le Wi-Fi WPA3 est…", ["plus sécurisé que WEP", "identique à WEP", "sans chiffrement"], 0)],
 "quiz-securite": [("Un mot de passe solide est…", ["123456", "une phrase longue et unique", "votre date de naissance"], 1),
                   ("Le phishing, c'est…", ["un message qui imite un service pour voler vos informations", "un antivirus", "un type de câble"], 0),
                   ("Face à un lien suspect…", ["cliquer vite", "ne pas cliquer et vérifier l'expéditeur", "le transférer à tous"], 1),
                   ("La double authentification ajoute…", ["un deuxième facteur de vérification", "deux mots de passe identiques", "un double compte"], 0),
                   ("Le partage de position doit être…", ["toujours actif", "activé seulement avec votre accord", "impossible à arrêter"], 1)],
}

@app.route("/games")
@login_required
def games():
    rows = db().execute("SELECT g.*, (SELECT MAX(score) FROM game_progress p WHERE p.game_code=g.code AND p.user_id=?) AS best, "
                        "(SELECT COUNT(*) FROM game_progress p WHERE p.game_code=g.code AND p.user_id=?) AS plays "
                        "FROM games g WHERE enabled=1", (session["uid"], session["uid"])).fetchall()
    return render_template("games.html", rows=rows)

@app.route("/games/<code>", methods=["GET", "POST"])
@login_required
def play(code):
    g = db().execute("SELECT * FROM games WHERE code=? AND enabled=1", (code,)).fetchone()
    if not g or code not in QUIZ:
        abort(404)
    qs = QUIZ[code]
    if request.method == "POST":
        score = sum(1 for i, q in enumerate(qs) if request.form.get("q%d" % i) == str(q[2]))
        db().execute("INSERT INTO game_progress(user_id,game_code,score,total,ts) VALUES(?,?,?,?,?)",
                     (session["uid"], code, score, len(qs), now())); db().commit()
        wrong = [(q[0], q[1][q[2]]) for i, q in enumerate(qs) if request.form.get("q%d" % i) != str(q[2])]
        return render_template("quiz_result.html", g=g, score=score, total=len(qs), wrong=wrong)
    return render_template("quiz.html", g=g, qs=[(q[0], q[1]) for q in qs])

# ───────────── Administration ─────────────
@app.route("/admin/users/<int:uid>/logout", methods=["POST"])
@role_required(*ADMINS)
def user_logout(uid):
    t = db().execute("SELECT role FROM users WHERE id=?", (uid,)).fetchone()
    if not t or (t["role"] != "client" and session["role"] != "super_admin"):
        abort(403)
    db().execute("UPDATE user_sessions SET revoked=1 WHERE user_id=?", (uid,)); db().commit()
    log("sessions_closed_by_admin", session["user"], "user %d" % uid); flash("Sessions fermées.")
    return redirect(url_for("admin_users"))

@app.route("/admin/roles", methods=["GET", "POST"])
@role_required(*ADMINS)
def admin_roles():
    if request.method == "POST":
        if session["role"] != "super_admin":
            abort(403)
        uid, role = request.form.get("uid", type=int), request.form.get("role")
        t = db().execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
        if not t or t["role"] == "super_admin" or role not in ("client", "admin"):
            abort(400)
        db().execute("UPDATE users SET role=? WHERE id=?", (role, uid)); db().commit()
        log("role_changed", session["user"], "%s -> %s" % (t["username"], role)); flash("Rôle modifié.")
        return redirect(url_for("admin_roles"))
    rows = db().execute("SELECT id,username,role,active FROM users ORDER BY id").fetchall()
    return render_template("roles.html", rows=rows)

@app.route("/admin/notifications", methods=["GET", "POST"])
@role_required(*ADMINS)
def admin_notifications():
    if request.method == "POST":
        msg = request.form.get("message", "").strip()[:300]
        if msg:
            ids = [r[0] for r in db().execute("SELECT id FROM users WHERE role='client' AND active=1")]
            db().executemany("INSERT INTO notifications(user_id,ts,level,message) VALUES(?,?,'info',?)", [(i, now(), msg) for i in ids])
            db().commit(); log("broadcast", session["user"], "%d client(s)" % len(ids)); flash("Notification envoyée à %d client(s)." % len(ids))
        return redirect(url_for("admin_notifications"))
    rows = db().execute("SELECT * FROM alerts ORDER BY id DESC LIMIT 30").fetchall()
    return render_template("admin_notifications.html", rows=rows)

@app.route("/admin/ai")
@role_required(*ADMINS)
def admin_ai():
    c = lambda q: db().execute(q).fetchone()[0]
    return render_template("admin_ai.html", live=bool(os.environ.get("EOG_AI_URL") and os.environ.get("EOG_AI_KEY")),
                           n=c("SELECT COUNT(*) FROM ai_messages WHERE role='user'"), u=c("SELECT COUNT(DISTINCT user_id) FROM ai_messages"))

@app.route("/admin/games", methods=["GET", "POST"])
@role_required(*ADMINS)
def admin_games():
    if request.method == "POST":
        db().execute("UPDATE games SET enabled=1-enabled WHERE code=?", (request.form.get("code"),)); db().commit()
        log("game_toggled", session["user"], request.form.get("code", "")); return redirect(url_for("admin_games"))
    rows = db().execute("SELECT g.*, (SELECT COUNT(*) FROM game_progress p WHERE p.game_code=g.code) AS plays FROM games g").fetchall()
    return render_template("admin_games.html", rows=rows)

@app.route("/admin/security", methods=["GET", "POST"])
@role_required(*ADMINS)
def admin_security():
    sup = session["role"] == "super_admin"
    if request.method == "POST":
        if not sup:
            abort(403)
        mx, mn = request.form.get("max_fails", "5"), request.form.get("lock_min", "15")
        mx = mx if mx.isdigit() and 1 <= int(mx) <= 20 else "5"
        mn = mn if mn.isdigit() and 1 <= int(mn) <= 1440 else "15"
        for k, v in (("max_fails", mx), ("lock_min", mn), ("require_verified", "1" if request.form.get("require_verified") else "0")):
            db().execute("INSERT OR REPLACE INTO settings(key,value) VALUES(?,?)", (k, v))
        db().commit(); log("security_settings_changed", session["user"]); flash("Paramètres de sécurité enregistrés.")
        return redirect(url_for("admin_security"))
    outbox = db().execute("SELECT * FROM outbox ORDER BY id DESC LIMIT 20").fetchall() if sup else []
    return render_template("admin_security.html", sup=sup, outbox=outbox, mx=setting("max_fails", "5"),
                           mn=setting("lock_min", "15"), rv=setting("require_verified", "0") == "1",
                           sessions_n=db().execute("SELECT COUNT(*) FROM user_sessions WHERE revoked=0").fetchone()[0],
                           providers=provider_list())

app.jinja_env.globals["providers"] = provider_list
app.jinja_env.globals["ICONS"] = ICONS   # visible aussi dans les macros importées (_ico.html)
