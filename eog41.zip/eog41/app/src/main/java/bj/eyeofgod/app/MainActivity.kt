package bj.eyeofgod.app

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.Manifest
import android.content.pm.PackageManager
import android.webkit.GeolocationPermissions
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.TextView
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import java.io.File

/**
 * Démarre le serveur Flask embarqué (Python/Chaquopy) puis affiche
 * l'interface dans une WebView. Les données sont dans l'espace privé
 * de l'application (filesDir/data).
 */
class MainActivity : Activity() {

    private lateinit var web: WebView
    private lateinit var status: TextView
    private var pendingGeo: Pair<String, GeolocationPermissions.Callback>? = null

    companion object {
        const val PORT = 47831
        const val URL = "http://127.0.0.1:$PORT/"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        status = TextView(this).apply {
            text = "EYE OF GOD\nDémarrage des services…"
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            textSize = 15f
            setPadding(48, 48, 48, 48)
        }
        web = WebView(this).apply {
            setBackgroundColor(Color.parseColor("#05070D"))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            webViewClient = object : WebViewClient() {
                override fun onReceivedError(
                    v: WebView, r: WebResourceRequest, e: WebResourceError
                ) {
                    if (r.isForMainFrame) showError("Erreur d'affichage : ${e.description}")
                }
            }
            // Géolocalisation : jamais sans la permission Android ET l'accord de l'utilisateur
            webChromeClient = object : WebChromeClient() {
                override fun onGeolocationPermissionsShowPrompt(
                    origin: String, cb: GeolocationPermissions.Callback
                ) {
                    if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                        == PackageManager.PERMISSION_GRANTED) {
                        cb.invoke(origin, true, false)
                    } else {
                        pendingGeo = Pair(origin, cb)
                        requestPermissions(arrayOf(
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION), 42)
                    }
                }
            }
            visibility = android.view.View.INVISIBLE
        }
        val root = FrameLayout(this)
        val lp = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        )
        root.addView(web, lp)
        root.addView(status, lp)
        setContentView(root)

        if (savedInstanceState != null) web.restoreState(savedInstanceState)
        startBackend()
    }

    private fun startBackend() {
        Thread {
            try {
                val webDir = copyAssets()
                val dataDir = File(filesDir, "data").apply { mkdirs() }
                if (!Python.isStarted()) Python.start(AndroidPlatform(this))
                Python.getInstance().getModule("launcher")
                    .callAttr("start", webDir.absolutePath, dataDir.absolutePath, PORT)
                runOnUiThread {
                    status.visibility = android.view.View.GONE
                    web.visibility = android.view.View.VISIBLE
                    if (web.url == null) web.loadUrl(URL)
                }
            } catch (t: Throwable) {
                runOnUiThread { showError("Le serveur local n'a pas démarré :\n${t.message}") }
            }
        }.start()
    }

    /** Copie assets/web vers filesDir/web (le code est toujours remplacé, jamais les données). */
    private fun copyAssets(): File {
        val target = File(filesDir, "web")
        target.deleteRecursively()
        copyDir("web", target)
        return target
    }

    private fun copyDir(assetPath: String, dest: File) {
        val children = assets.list(assetPath) ?: emptyArray()
        if (children.isEmpty()) {
            dest.parentFile?.mkdirs()
            assets.open(assetPath).use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
        } else {
            dest.mkdirs()
            for (c in children) copyDir("$assetPath/$c", File(dest, c))
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        pendingGeo?.let { it.second.invoke(it.first, res.any { r -> r == PackageManager.PERMISSION_GRANTED }, false) }
        pendingGeo = null
    }

    private fun showError(msg: String) {
        status.visibility = android.view.View.VISIBLE
        status.text = msg
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
