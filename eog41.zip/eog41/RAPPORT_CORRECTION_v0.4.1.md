# Correctif v0.4.1 — erreur « PermissionError [Errno 13] … backups/eyeofgod_avant_v3_….db »

## Cause
`migrate()` sauvegardait la base avec `shutil.copy2`, qui copie le fichier PUIS ses métadonnées (`copystat` : dates, droits,
attributs étendus SELinux). Sur Android, cette seconde étape est refusée (Errno 13) même dans le dossier privé de l'appli.
Le fichier de sauvegarde était créé, puis l'exception arrêtait le serveur : plantage à chaque démarrage, avant toute migration.
(Cause déduite du message et de la reproduction ci-dessous ; je n'ai pas d'appareil Android pour la confirmer directement.)

## Correction
1. `make_backup()` : sauvegarde par l'API SQLite (`sqlite3.Connection.backup`) — aucune copie de fichier ni de métadonnées, cohérente même en mode WAL.
2. Écriture dans `…/files/data/backups/<nom>.part`, puis **vérification** (`PRAGMA integrity_check` + nombre de lignes de chaque table identique à la base), puis renommage atomique. Un fichier invalide n'est jamais présenté comme sauvegarde.
3. Test d'écriture du dossier avant sauvegarde ; en cas d'échec, message clair : étape, dossier, existence, droit d'écriture, détail technique.
4. Si la sauvegarde échoue : AUCUNE migration, base inchangée, serveur non démarré, message affiché à l'écran (Kotlin). La sauvegarde n'est pas désactivée.
5. Si une migration échoue : message avec le chemin de la sauvegarde ; les migrations sont idempotentes (relance possible).
6. Seul le fichier partiel `.part` peut être supprimé ; la base d'origine ne l'est jamais.
7. Précaution Android 9 : le scan n'utilise plus l'UPSERT `ON CONFLICT … DO UPDATE` (SQLite ≥ 3.24 ; Android 9 embarque 3.22 si Chaquopy utilise la bibliothèque système) : UPDATE puis INSERT, même comportement.
8. Version 0.4.1 (versionCode 5), même clé de signature : installation par-dessus la 0.4.0, données conservées.

## Emplacement des données
`Context.filesDir/data` (espace privé interne, aucune permission Android requise) : base, clé, `backups/`.

## Tests exécutés (Python 3.12 / SQLite 3.45 sur Linux — PAS sur un téléphone)
| Test | Résultat |
|---|---|
| Reproduction de l'erreur avec le code v0.4.0 (copystat refusé) | Même PermissionError ; fichier de sauvegarde laissé à moitié créé |
| Code v0.4.1, avec copy2/copystat/copyfile/copy tous **refusés** (comportement Android simulé), base v3 en mode WAL | Migration v3→v4 OK |
| Fichier de sauvegarde réellement créé, non vide, sans `.part` ni sonde restants | OK |
| `integrity_check` = ok ; sauvegarde = état v3 d'avant migration ; contenu identique (toutes tables/lignes) | OK |
| Comptes, réseaux, appareils, positions conservés après migration | OK |
| 2e démarrage : pas de nouvelle sauvegarde, pas de doublon | OK |
| Dossier `backups` impossible à créer : erreur claire, base inchangée (SHA-256 identique, v3) | OK |
| Disque plein à la finalisation : `.part` supprimé, aucune fausse sauvegarde, base intacte ; après libération, tout passe | OK |
| Sauvegarde non conforme (contenu divergent) : détectée, migration refusée | OK |
| Serveur réel via `launcher.start` : `/`→302, `/login` 200, CSS 200, version 0.4.1, 2e appel sans effet | OK |
| Installation neuve : `/setup` accessible, pas de sauvegarde inutile | OK |
| Sauvegarde en échec : `RuntimeError` clair remonté, serveur non démarré, base v3 intacte | OK |
| Suite v0.4 complète (53 vérifications) + scan sans UPSERT + GPS/consentement | OK |

## NON vérifié
Exécution sur Android 9 réel · compilation Gradle/APK · comportement exact de la bibliothèque SQLite sous Chaquopy (la requête de scan a été réécrite pour 3.22 mais testée ici sur 3.45) · affichage du message d'erreur dans l'écran Kotlin.
